package kr.or.ddit.vo;

import lombok.Data;

@Data
public class MemberAuthVO {
	private int userNo;
	private String auth;
}
