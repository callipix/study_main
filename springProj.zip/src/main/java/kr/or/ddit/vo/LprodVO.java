package kr.or.ddit.vo;

import lombok.Data;

@Data
public class LprodVO {
	private int lprodId;
	private String lprodGu;
	private String lprodNm;
}
