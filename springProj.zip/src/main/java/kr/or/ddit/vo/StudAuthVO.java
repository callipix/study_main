package kr.or.ddit.vo;

import lombok.Data;

@Data
public class StudAuthVO {
	private String studId;
	private String auth;
}
